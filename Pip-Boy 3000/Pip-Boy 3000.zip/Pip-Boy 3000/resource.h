//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Pip-Boy 3000.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_PIPBOY3000_FORM             101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_PipBoy3000TYPE              130
#define IDD_DIALOG_WEAPONS              310
#define IDB_APPAREL                     313
#define IDB_WEAPONS                     314
#define IDB_AID                         315
#define IDD_DIALOG1                     318
#define IDD_DIALOG2                     320
#define IDD_DIALOG_DROP                 320
#define IDC_STATIC_APPAREL              1001
#define IDC_STATIC_WEAPONS              1002
#define IDC_STATIC_AID                  1003
#define IDC_LIST_INVENTORY              1004
#define IDC_EDIT1                       1005
#define IDC_IMAGE_WEAPONS               1006
#define IDC_IMAGE_APPAREL               1007
#define IDC_IMAGE_AID                   1008
#define IDC_BUTTON_DROP                 1009
#define IDC_LIST_ITEMS                  1013
#define IDC_BUTTON_PICKUP               1014
#define IDC_LIST_WEAPONS                1016
#define IDC_LIST3                       1017
#define IDC_LIST1                       1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        322
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
